import { API_KEY } from './utils.js';

export function dumpVideoElement(video) {
  if (!video) return 'No video element provided';
  try {
    return {
      src: video.src || 'no src',
      currentSrc: video.currentSrc || 'no currentSrc',
      readyState: video.readyState,
      paused: video.paused,
      duration: video.duration || 0,
      videoWidth: video.videoWidth || 0,
      videoHeight: video.videoHeight || 0,
      hasChildNodes: video.hasChildNodes(),
      parentNode: video.parentNode ? video.parentNode.tagName : 'none',
      attributes: Array.from(video.attributes).map(attr => `${attr.name}="${attr.value}"`)
    };
  } catch (e) {
return 'Error dumping video element';
  }
}

export function findPlayer(callback) {
  let attempts = 0;
  const maxAttempts = 40;
  
  function searchForPlayer() {
if (attempts >= maxAttempts) {
return;
    }
    
    const selectors = [
      'video',
      '.player-container video',
      '[class*="player"] video',
      '#stremio-player video',
      '.stremio-video video',
      '[data-video-player] video'
    ];
    
    let foundVideos = [];
    selectors.forEach(selector => {
      const elements = document.querySelectorAll(selector);
foundVideos = [...foundVideos, ...elements];
    });
if (foundVideos.length > 0) {
      foundVideos.forEach((video, index) => {
});
      
      const validPlayer = foundVideos.find(video =>
        video instanceof HTMLVideoElement &&
        (video.readyState > 0 || video.src || video.querySelector('source'))
      );
      
      if (validPlayer) {
callback(validPlayer);
        return;
      }
    }
    
    attempts++;
    setTimeout(searchForPlayer, 1000);
  }
  
  searchForPlayer();
}

export async function checkAndSkip(player, skipSegments, isEnabled, showSkipNotification) {
  if (!isEnabled || !player || skipSegments.length === 0) {
    return false;
  }
  
  try {
    const currentTime = player.currentTime;
    for (const segment of skipSegments) {
      // Increased the detection window slightly and added bounds checking
      const isApproachingSegment = (
        currentTime >= (segment.start - 1.0) && 
        currentTime < segment.end && 
        segment.start >= 0 && 
        segment.end > segment.start && 
        segment.end <= player.duration
      );
      
      if (isApproachingSegment) {
        player.currentTime = segment.end;
        await showSkipNotification(segment);
        return true;
      }
    }
  } catch (error) {
    console.error('Error in checkAndSkip:', error);
  }
  return false;
}

export async function fetchSkipSegments(videoId, API_BASE_URL, visualizer) {
  if (!videoId) {
return [];
  }

  try {
const response = await fetch(`${API_BASE_URL}/api/segments/${encodeURIComponent(videoId)}`, {
      headers: {
        'X-API-Key': API_KEY
      }
    });
    
    if (!response.ok) {
      const errorData = await response.json().catch(() => null);
      throw new Error(`Failed to fetch segments: ${response.status}`);
    }
    
    const segments = await response.json();
if (visualizer) {
      // Clear visualization first
      visualizer.clear();
      
      // Initialize visualization if we have valid segments
      if (segments.length > 0) {
        const slider = document.querySelector('.slider-container-nJz5F');
        if (slider) {
// Sort segments by start time to ensure consistent visualization
          segments.sort((a, b) => a.start - b.start);
          
          // Wait for metadata to load before visualizing
          await new Promise((resolve) => {
            const maxAttempts = 50; // 5 seconds total
            let attempts = 0;
            
            const checkReady = () => {
              const player = document.querySelector('video');
              if (!player) {
resolve();
                return;
              }

              if (player.readyState >= 1 && player.duration > 0) {
resolve();
              } else {
                attempts++;
                if (attempts >= maxAttempts) {
resolve();
                  return;
                }
setTimeout(checkReady, 100);
              }
            };
            checkReady();
          });
          
          // Add each segment to visualization
          for (const segment of segments) {
            if (segment && typeof segment.start === 'number' && typeof segment.end === 'number') {
await visualizer.setStartTime(segment.start);
              await visualizer.setEndTime(segment.end);
            }
          }
        }
      }
    }
    
    return segments;
  } catch (error) {
if (visualizer) {
      visualizer.clear();
    }
    return [];
  }
}

// Add a function to help with visualization initialization
export function initializeVisualization(player, createVisualizer) {
  return new Promise((resolve) => {
    const maxAttempts = 20;
    let attempts = 0;

    function tryInit() {
      const slider = document.querySelector('.slider-container-nJz5F');
      if (!slider || !player) {
        if (attempts < maxAttempts) {
attempts++;
          setTimeout(tryInit, 250);
        } else {
resolve(null);
        }
        return;
      }

      // Make sure player has duration
      if (!player.duration && attempts < maxAttempts) {
attempts++;
        setTimeout(tryInit, 250);
        return;
      }

      const visualizer = createVisualizer(player, slider);
resolve(visualizer);
    }

    tryInit();
  });
}